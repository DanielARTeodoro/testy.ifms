-- -------------- Tutorial ---------------
create database pizza_ifms;
use pizza_ifms;